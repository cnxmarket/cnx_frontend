import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar/Sidebar";
import Dashboard from "./pages/Dashboard";
import OrderTable from "./components/OrderTable";

export default function App() {
  return (
    <Router>
      <div className="flex min-h-screen overflow-x-hidden">
  <Sidebar />
  <main className="flex-1 overflow-x-hidden">
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/orders" element={<OrderTable />} />
    </Routes>
  </main>
</div>

    </Router>
  );
}
