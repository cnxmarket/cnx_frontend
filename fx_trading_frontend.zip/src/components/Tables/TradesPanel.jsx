import { useState } from "react";

// Mock data
const mockPositions = [
  { id: "POS-001", symbol: "EURUSD", side: "Buy", lots: 1.0, entry: 1.07325, current: 1.07410, pnl: 85.0 },
  { id: "POS-002", symbol: "GBPUSD", side: "Sell", lots: 0.5, entry: 1.24310, current: 1.24210, pnl: 50.0 },
];

const mockHistory = [
  { id: "TRD-101", symbol: "USDJPY", side: "Buy", lots: 2.0, entry: 148.910, exit: 149.210, pnl: 300.0, closedAt: "2025-10-09 10:15" },
  { id: "TRD-102", symbol: "AUDUSD", side: "Sell", lots: 1.0, entry: 0.65210, exit: 0.65180, pnl: 30.0, closedAt: "2025-10-09 09:45" },
];

export default function TradesPanel() {
  const [tab, setTab] = useState("positions");

  return (
    <div className="w-full">
      {/* Pill Navigation */}
      <div className="flex gap-2 sm:gap-3 mb-4 flex-wrap">
        <button
          onClick={() => setTab("positions")}
          className={`px-4 sm:px-6 py-2 rounded-full text-sm sm:text-base font-semibold transition ${tab === "positions"
              ? "bg-green-500/20 text-green-400 border border-green-400/50"
              : "bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10"
            }`}
        >
          Open Positions
        </button>
        <button
          onClick={() => setTab("history")}
          className={`px-4 sm:px-6 py-2 rounded-full text-sm sm:text-base font-semibold transition ${tab === "history"
              ? "bg-green-500/20 text-green-400 border border-green-400/50"
              : "bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10"
            }`}
        >
          Trade History
        </button>
      </div>

      {/* Responsive Table Container */}
      <div className="w-full overflow-x-auto max-h-[300px] overflow-y-auto rounded-xl border border-white/10">
        {tab === "positions" ? <PositionsTable data={mockPositions} /> : <HistoryTable data={mockHistory} />}
      </div>

    </div>
  );
}

function PositionsTable({ data }) {
  return (
    <table className="min-w-full text-xs sm:text-sm lg:text-base">
      <thead className="bg-white/10 text-gray-100">
        <tr>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">ID</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">SYMBOL</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">SIDE</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">LOTS</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">ENTRY</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">CURRENT</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">P&L</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">ACTION</th>
        </tr>
      </thead>
      <tbody className="text-gray-300">
        {data.map((pos) => (
          <tr key={pos.id} className="border-b border-white/10 hover:bg-white/5">
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 font-medium whitespace-nowrap">{pos.id}</td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">{pos.symbol}</td>
            <td className={`px-2 sm:px-4 lg:px-6 py-2 sm:py-3 font-bold whitespace-nowrap ${pos.side === "Buy" ? "text-green-400" : "text-red-400"}`}>
              {pos.side}
            </td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">{pos.lots}</td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">{pos.entry}</td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">{pos.current}</td>
            <td className={`px-2 sm:px-4 lg:px-6 py-2 sm:py-3 font-semibold whitespace-nowrap ${pos.pnl >= 0 ? "text-green-400" : "text-red-400"}`}>
              {pos.pnl >= 0 ? "+" : ""}{pos.pnl.toFixed(2)}
            </td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">
              <button className="text-xs bg-red-600/20 hover:bg-red-600/30 px-2 sm:px-3 py-1 rounded-lg text-red-400 transition">
                Close
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function HistoryTable({ data }) {
  return (
    <table className="min-w-full text-xs sm:text-sm lg:text-base">
      <thead className="bg-white/10 text-gray-100">
        <tr>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">ID</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">SYMBOL</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">SIDE</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">LOTS</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">ENTRY</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">EXIT</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">P&L</th>
          <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-left font-bold whitespace-nowrap">CLOSED AT</th>
        </tr>
      </thead>
      <tbody className="text-gray-300">
        {data.map((trade) => (
          <tr key={trade.id} className="border-b border-white/10 hover:bg-white/5">
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 font-medium whitespace-nowrap">{trade.id}</td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">{trade.symbol}</td>
            <td className={`px-2 sm:px-4 lg:px-6 py-2 sm:py-3 font-bold whitespace-nowrap ${trade.side === "Buy" ? "text-green-400" : "text-red-400"}`}>
              {trade.side}
            </td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">{trade.lots}</td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">{trade.entry}</td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 whitespace-nowrap">{trade.exit}</td>
            <td className={`px-2 sm:px-4 lg:px-6 py-2 sm:py-3 font-semibold whitespace-nowrap ${trade.pnl >= 0 ? "text-green-400" : "text-red-400"}`}>
              {trade.pnl >= 0 ? "+" : ""}{trade.pnl.toFixed(2)}
            </td>
            <td className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-gray-400 text-xs sm:text-sm whitespace-nowrap">{trade.closedAt}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
