import React from "react";

const orders = [
  {
    id: "ORD-001",
    date: "2025-10-09 10:00",
    pair: "EURUSD",
    side: "Buy",
    type: "Limit",
    price: "1.07320",
    lots: "1.00",
    status: "Open"
  },
  {
    id: "ORD-002",
    date: "2025-10-09 09:45",
    pair: "GBPUSD",
    side: "Sell",
    type: "Market",
    price: "1.24310",
    lots: "0.50",
    status: "Filled"
  },
  {
    id: "ORD-003",
    date: "2025-10-09 09:20",
    pair: "USDJPY",
    side: "Buy",
    type: "Stop",
    price: "148.910",
    lots: "2.00",
    status: "Rejected"
  }
];

export default function OrderTable() {
  return (
    <div className="bg-[#181926] rounded-2xl shadow-lg p-6">
      <h2 className="text-2xl font-bold text-white mb-4">Order Table</h2>
      <table className="min-w-full">
        <thead className="bg-white/10 text-gray-100">
          <tr>
            <th className="px-6 py-4 text-left font-bold">ORDER ID</th>
            <th className="px-6 py-4 text-left font-bold">DATE</th>
            <th className="px-6 py-4 text-left font-bold">PAIR</th>
            <th className="px-6 py-4 text-left font-bold">SIDE</th>
            <th className="px-6 py-4 text-left font-bold">TYPE</th>
            <th className="px-6 py-4 text-left font-bold">PRICE</th>
            <th className="px-6 py-4 text-left font-bold">LOTS</th>
            <th className="px-6 py-4 text-left font-bold">STATUS</th>
            <th className="px-6 py-4 text-left font-bold">ACTION</th>
          </tr>
        </thead>
        <tbody className="text-gray-300 text-lg">
          {orders.map(order => (
            <tr key={order.id} className="border-b border-white/10">
              <td className="px-6 py-4 font-medium">{order.id}</td>
              <td className="px-6 py-4">{order.date}</td>
              <td className="px-6 py-4">{order.pair}</td>
              <td className={`px-6 py-4 font-bold ${order.side === "Buy" ? "text-green-400" : "text-red-400"}`}>{order.side}</td>
              <td className="px-6 py-4">{order.type}</td>
              <td className="px-6 py-4">{order.price}</td>
              <td className="px-6 py-4">{order.lots}</td>
              <td className="px-6 py-4">
                <span
                  className={`px-3 py-1 rounded-full ${
                    order.status === "Open"
                      ? "bg-yellow-500/20 text-yellow-400"
                      : order.status === "Filled"
                      ? "bg-green-500/20 text-green-400"
                      : order.status === "Rejected"
                      ? "bg-red-500/20 text-red-400"
                      : "bg-gray-400/20 text-gray-400"
                  }`}
                >
                  {order.status}
                </span>
              </td>
              <td className="px-6 py-4">
                <button className="text-sm bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg text-gray-100 transition">
                  View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
