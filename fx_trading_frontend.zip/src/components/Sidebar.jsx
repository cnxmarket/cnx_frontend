export default function Sidebar({ pairs, activePair, onSelect }) {
    return (
      <div className="w-60 p-4 backdrop-blur-md bg-white/10 border-r border-white/20 flex flex-col">
        <h1 className="text-xl font-bold mb-6 tracking-wide">FX Pairs</h1>
        <ul className="space-y-3">
          {pairs.map((pair) => (
            <li
              key={pair}
              onClick={() => onSelect(pair)}
              className={`cursor-pointer px-3 py-2 rounded-lg transition ${
                activePair === pair
                  ? "bg-green-500/20 border border-green-500/40 text-green-400"
                  : "hover:bg-white/10"
              }`}
            >
              {pair}
            </li>
          ))}
        </ul>
      </div>
    );
  }
  