import LivePrice from "../LivePrice";
import {
  HomeIcon,
  ChartBarIcon,
  CurrencyDollarIcon,
  ClipboardListIcon,
  ViewGridIcon,
  LockClosedIcon,
  SupportIcon,
  MenuAlt2Icon,
} from "@heroicons/react/outline";
import { Link } from "react-router-dom";
import { useState } from "react";

const pairs = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD"];

export default function Sidebar({ activePair, onSelect }) {
  const [railOpen, setRailOpen] = useState(false); // for < lg slide-out
  const [showPairs, setShowPairs] = useState(true);

  // Widths:
  // xl: full (w-64), lg/md/sm: minified rail (w-16). On mobile allow slide-out.
  return (
    <>
      {/* Overlay for mobile slide-out */}
      <div
        className={`fixed inset-0 bg-black/40 z-40 lg:hidden transition-opacity ${railOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`}
        onClick={() => setRailOpen(false)}
      />

      {/* Sidebar container */}
      <aside
        className={`
          fixed lg:static z-50 h-screen border-r border-white/10 bg-[#181926] text-gray-100
          flex flex-col transition-[width,transform]
          w-16 xl:w-64
          ${railOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
        `}
      >
        {/* Top: logo + burger */}
        <div className="p-4 xl:p-6 border-b border-white/10 flex items-center gap-3">
          <button
            className="lg:hidden inline-flex items-center justify-center rounded-lg p-2 hover:bg-white/10"
            onClick={() => setRailOpen((v) => !v)}
          >
            <MenuAlt2Icon className="h-6 w-6 text-gray-200" />
          </button>
          <span className="hidden xl:block text-yellow-400 text-2xl font-bold tracking-wide">
            FXTrade Admin
          </span>
        </div>

        {/* Scroll area */}
        <nav className="flex-1 px-2 xl:px-4 py-4 overflow-y-auto">
          {/* Main Navigation */}
          <ul className="space-y-1">
            <SidebarItem to="/" icon={<HomeIcon className="h-5 w-5" />} label="Dashboard" />
            <SidebarItem to="/reports" icon={<ChartBarIcon className="h-5 w-5" />} label="Reports" />
            <SidebarItem to="/markets" icon={<CurrencyDollarIcon className="h-5 w-5" />} label="Markets / Tickers" />
          </ul>

          {/* Transactions */}
          <SectionLabel>Transactions</SectionLabel>
          <ul className="space-y-1">
            <SidebarItem to="/orders" icon={<ClipboardListIcon className="h-5 w-5" />} label="Order Table" />
            <RailItem icon={<ViewGridIcon className="h-5 w-5" />} label="Real-Time Positions" />
            <RailItem icon={<ViewGridIcon className="h-5 w-5" />} label="Trade History" />
          </ul>

          {/* Orders */}
          <SectionLabel>Orders</SectionLabel>
          <ul className="space-y-1">
            <RailItem icon={<ViewGridIcon className="h-5 w-5" />} label="Place New Order" />
          </ul>

          {/* Authentication */}
          <SectionLabel>Authentication</SectionLabel>
          <ul className="space-y-1">
            <RailItem icon={<LockClosedIcon className="h-5 w-5" />} label="Authentication" />
          </ul>

          {/* Support */}
          <SectionLabel>Support</SectionLabel>
          <ul className="space-y-1">
            <RailItem icon={<SupportIcon className="h-5 w-5" />} label="Support" />
          </ul>

          {/* Forex Pairs */}
          <div className="mt-6">
            <button
              onClick={() => setShowPairs((v) => !v)}
              className="w-full text-left text-xs uppercase text-gray-400 mb-2 font-semibold hover:text-gray-200 transition"
              title="Forex Pairs"
            >
              <span className="hidden xl:inline">Forex Pairs</span>
              <span className="xl:hidden">Pairs</span>
            </button>

            <div className={`${showPairs ? "block" : "hidden"} space-y-2`}>
              {pairs.map((p) => (
                <div
                  key={p}
                  onClick={() => onSelect?.(p)}
                  className={`cursor-pointer rounded-lg transition 
                    ${activePair === p ? "bg-green-500/20" : "hover:bg-white/10"}`}
                  title={p}
                >
                  {/* In rail mode, shrink LivePrice height/padding */}
                  <div className="xl:block hidden">
                    <LivePrice symbol={p} />
                  </div>
                  <div className="xl:hidden px-3 py-2 flex items-center justify-between">
                    <span className="text-sm font-semibold">{p}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </nav>
      </aside>

      {/* Rail hover expansion for desktop (optional): show a tooltip-like label on hover */}
      <style>{`
        @media (min-width: 1024px) and (max-width: 1279px) {
          /* lg-only: keep rail at 4rem and show labels as tooltips on hover via title attr */
        }
      `}</style>
    </>
  );
}

function SidebarItem({ to, icon, label }) {
  return (
    <li>
      <Link
        to={to}
        className="group flex items-center gap-3 py-2 px-2 xl:px-3 rounded-lg hover:bg-white/10 cursor-pointer"
        title={label}
      >
        <span className="text-gray-300">{icon}</span>
        <span className="font-semibold hidden xl:inline">{label}</span>
      </Link>
    </li>
  );
}

function RailItem({ icon, label, onClick }) {
  return (
    <li
      onClick={onClick}
      className="group flex items-center gap-3 py-2 px-2 xl:px-3 rounded-lg hover:bg-white/10 cursor-pointer"
      title={label}
    >
      <span className="text-gray-300">{icon}</span>
      <span className="font-semibold hidden xl:inline">{label}</span>
    </li>
  );
}

function SectionLabel({ children }) {
  return (
    <div className="mt-6">
      <div className="text-xs uppercase text-gray-400 font-semibold mb-2 hidden xl:block">{children}</div>
    </div>
  );
}
